module.exports = {
  BOT_TOKEN: "Token Mu Kontol",
};